<?php

class Registration extends Data
{
     public $db;

     function checkUser($email,$password){

      $res = $this->db->prepare("SELECT `id`, `email`, `password` FROM `users` WHERE `email` = :email");
          $res->execute(array('email' => $email));
          $rezult = $res->fetchAll(PDO::FETCH_ASSOC);
          print_r($rezult);
     }
     function registrationUser($email,$password){

     }
     function loginUser($id){

     }
     function logoutUser(){

     }
}