<?php

class ShowData extends Data
{
     public $db;


     function getShowById($id)
     {
          $res = $this->db->prepare("
               SELECT seansu_new.`id`, seansu_new.`name`, seansu_new.description,seansu_new.`picture`, 
               seansu_new.`theatre_id` , theatre.`name`as theatrename , 
               seans_time.time,seansu_new.janr, janru.name as jname
               FROM `seansu_new` 
               LEFT JOIN theatre 
               on theatre.id = seansu_new.theatre_id 
               LEFT JOIN seans_time
               on `seans_time`.`seans_id` =  seansu_new.`id`
               LEFT JOIN janru
               on    janru.id = seansu_new.janr
               WHERE seansu_new.id = :id
          ");
          $res->execute(array('id' => $id));
          $rezult = $res->fetchAll(PDO::FETCH_ASSOC);
          if (!empty($rezult)) {
               return $rezult[0];
          }
          return false;
     }

     function getSeats($id){
         $res = $this->db->prepare("SELECT  `row`, `seats`, `type`, `cost`, `show`, `status` FROM `seats` WHERE `show` = :id");
          $res->execute(array('id' => $id));
          $rezult = $res->fetchAll(PDO::FETCH_ASSOC);
          if (!empty($rezult)) {
               return $rezult;
          }
          return false;
     }
     function getStatusSeat($idshow,$idseats){

//          $res = $this->db->prepare("SELECT `seats`, `cost`, `show`, `status` FROM `seats`
//                            WHERE `row` =:row and `seats` =:seat and `show` = :idshow ");

          foreach ($idseats as $row=>$idseat) {
               foreach ($idseat as $seat) {
                    $res = $this->db->query("SELECT `seats`, `cost`, `show`, `status` FROM `seats` 
                            WHERE `row` =$row and `seats` =$seat and `show` = $idshow ");
                    //$res->execute(array('row' => $row,'seat' => $seat,'show' => $idshow));
                         //$res->setFetchMode(PDO::FETCH_ASSOC);
                    while ($roz = $res->fetch(PDO::FETCH_ASSOC))
                    {
                         $rezult[] = $roz;
                    }
               }
          }
          return $rezult;
     }
}