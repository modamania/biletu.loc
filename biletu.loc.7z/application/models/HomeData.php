<?php


class HomeData extends Data
{
     public $db;


}