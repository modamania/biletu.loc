<div class="footer">
     <!--<div class="footerlogo"></div>
     <div class="copy">
          </div>
     <div class="rules"></div>
     <div class="banners">
          <br></div>-->

     <div class="banners">
          © <?php echo date('Y') ?> пример сайта с использованием MVC модели. Сссылка на код <a
              href="https://github.com/d-yuri">GitHub</a>
          <br></div>
</div>


</div>

</body></html>

