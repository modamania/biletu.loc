<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="language" content="ru">
<title>Театр</title>
<meta name="description" content="">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link href="/application/views/css/style.css" rel="stylesheet" type="text/css">
<body>
<div class="page">
<div class="header">



