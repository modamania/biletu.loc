<?php


class ShowController
{
     function actionView($id)
     {
          $sh = new ShowData();
          $show = $sh->getShowById($id);
          CategoryController::getCatList();
          include ROOT . '/application/views/Show.php';

     }

     function actionGetSeats($id)
     {
          $st = new ShowData();
          $seats = $st->getSeats($id);
          foreach ($seats as $name=>$seat) {
               $seatres[$seat['row']][]= $seat;
          }
          include ROOT . '/application/views/template/zal.php';
     }

     function actionSell(){
          $st = new ShowData();
          $idswhow = $_POST['show'];
          $seats = self::arrfilter($_POST['ticket']);
          $reschek = $st->getStatusSeat($idswhow,$seats);
          $mail = self::chekValue($_POST['email'],15,4,true);
          $password = self::chekValue($_POST['pass'],15,4,false);
          if($mail === true && $password === true){
               $reg = new Registration();
               $reg->checkUser($mail,$password);
               echo $mail;
               echo $password;
          }


     }

     private function arrfilter($arr){
          $sea = explode('&',$arr);

          foreach ($sea as $seat) {
               $seats[] = explode('=',$seat);
          }

          foreach ($seats as $seat) {
               if(count($seat) == 2){
                    $final[$seat[0]][] = $seat[1];
               }
          }

          return $final;
     }

     private function chekValue($val,$max,$min,$mail=false){
          $len = strlen($val);
          if(!empty($val)&& $len <=$max && $len >=$min){
               if($mail === true){
                    $rv = explode('@',$val);
                    if(count($rv) !=2){
                         return 'Неправильные емаил';
                    }
               }
               return true;
          }else{
               return 'Слишком длинное или короткое';
          }
     }
}
