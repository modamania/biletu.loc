<?php
session_start();
//print_r(dirname(__FILE__));
//echo $_SERVER[REQUEST_URI];

define('ROOT', $_SERVER['DOCUMENT_ROOT']);

require_once(ROOT . '/components/Router.php');
require_once(ROOT . '/components/Db.php');

require_once(ROOT . '/components/Autoload.php');
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])
    == 'xmlhttprequest'
) {
     // Если к нам идёт Ajax запрос, то ловим его
     $ajax = true;
}

//include ROOT . '/application/views/Header.php';
if (!$ajax) {
     include ROOT . '/application/views/Header.php';
}
$route = new Router();
$result = $route->run();
if (!$ajax) {
     include ROOT . '/application/views/Footer.php';
}


//include 'templete\products.html';
//include 'templete\footer.html';
//include ROOT . '/application/views/Footer.php';
