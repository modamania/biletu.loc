<?php

return array(
    'host' => 'localhost',
    'user' => 'root',
    'dbname' => 'biletu',
    'password' => ''
);