
<form action="" method="post" id="form">
     <span>Введите ваши данные:</span> <br/> <br/>
          <label>Email:</label><br/>
          <input  name="email" type="text""><br/><br/>
          <label>пароль:</label><br/>
          <input  name="pass" type="password" "><br/><br/>
          <input type="button" class="enter" value="Воход/Регистрация">
          <!--<input type="button" class="register" value="Зарегистироваться"><br/><br/>-->
     </form>

