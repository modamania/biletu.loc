<?php


class Filter
{

     static public function Where(array $where){

     }

     static public function Join(array $join){

     }
}