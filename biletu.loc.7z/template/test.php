<?php
class Data{
 public $db;
     public $time;
     public function __construct()
     {
          $this->db = Db::getConnection();
          $this->time = time();
     }

     public function getAllSeans($table,$fields,$page=0,$time=false,$where=null){

     }
     public function getCountRow($page,$table,$where=null){

     }


}