function addcomment(){
  var str = $("#cform").serialize();	
  $('#loading').html('<img src="/img/loading.gif" width="20" height="20" alt="" />');
  $.post('/use/back/cmmnts.php',str,function(){
    $('#sform').html('<p>Спасибо за ваш отзыв.</p>');
  });
}
