var matched, browser;

jQuery.uaMatch = function( ua ) {
    ua = ua.toLowerCase();

    var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
        /(webkit)[ \/]([\w.]+)/.exec( ua ) ||
        /(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
        /(msie) ([\w.]+)/.exec( ua ) ||
        ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
        [];

    return {
        browser: match[ 1 ] || "",
        version: match[ 2 ] || "0"
    };
};

matched = jQuery.uaMatch( navigator.userAgent );
browser = {};

if ( matched.browser ) {
    browser[ matched.browser ] = true;
    browser.version = matched.version;
}

// Chrome is Webkit, but Webkit is also Safari.
if ( browser.chrome ) {
    browser.webkit = true;
} else if ( browser.webkit ) {
    browser.safari = true;
}

jQuery.browser = browser;

function $id(id) {
  return document.getElementById(id); 
}
function gv(v){
  document.getElementById(v).style.visibility='visible';
}
function gh(v){
  document.getElementById(v).style.visibility='hidden';
}
function closeDiv(){
  $(".buyticket").css("visibility","hidden");
}
$(document).ready(function() {  
  $('body').delegate('.s-buy-link','click',function(event){      	
    event.preventDefault();  
    $('body').find('.tickets-frame').remove();
    var link = $(this).attr('data-link');  
    var parentDiv = $(this).parents('p');    
    parentDiv.before('<div class="back" style="visibility: visible;"></div><div class="tickets-frame"><iframe class="i-wrap wrapperwide" name="iframe" src="" width="100%" height="0" scrolling="auto" align="top" frameborder="0" hspace="10"></iframe><div><a href="#" class="s-close">закрыть</a></div></div>');    
    $('body').find('.tickets-frame').css({'display':'block','visibility':'visible'});
    $('body').find('.i-wrap').css({'height':'810px'}).attr('src',link);     
  });
  $('body').delegate('.s-close','click',function(event){
    var div = $(this).parent().parent();
    var destination = div.offset().top;    
    if ($.browser.safari) {
      $('body').animate({ scrollTop: destination }, 1100);
    } else {
      $('html').animate({ scrollTop: destination }, 1100);
    }    
  	div.remove();
  	$('body').find('.back').css('visibility','hidden');
  });    
});